#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_PNG_Image.H>

int main() {
    Fl_Window window(400, 400, "FLTK Image Support");
    Fl_PNG_Image image("image.png");
    window.end();
    window.show();
    return Fl::run();
}
